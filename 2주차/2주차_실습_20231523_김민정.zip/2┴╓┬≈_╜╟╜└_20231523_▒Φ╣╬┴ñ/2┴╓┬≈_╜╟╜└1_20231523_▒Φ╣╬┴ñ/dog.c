#include "animal.h"
#include <stdio.h>

void dog(){
	printf("dog");
}
