void dog();
void blackcow();
void turtle();
