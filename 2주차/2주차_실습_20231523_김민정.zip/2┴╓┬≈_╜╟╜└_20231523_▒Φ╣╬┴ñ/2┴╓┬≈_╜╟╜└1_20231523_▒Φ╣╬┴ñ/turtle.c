#include "animal.h"
#include <stdio.h>

void turtle(){

	printf("turtle");

}
