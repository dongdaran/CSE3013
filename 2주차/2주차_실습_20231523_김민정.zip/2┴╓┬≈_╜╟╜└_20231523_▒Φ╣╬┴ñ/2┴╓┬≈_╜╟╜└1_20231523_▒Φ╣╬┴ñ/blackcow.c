#include "animal.h"
#include <stdio.h>

void blackcow(){
	printf("blackcow");
}
